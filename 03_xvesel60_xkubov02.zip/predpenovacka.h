#ifndef PREDPENOVACKA_H
#define PREDPENOVACKA_H

#include <simlib.h>

class Predpenovacka : public Facility
{


    public:
        Predpenovacka();
};

#endif // PREDPENOVACKA_H
