#include "sklad.h"

Sklad::Sklad()
{

}

Sklad::~Sklad()
{

}
