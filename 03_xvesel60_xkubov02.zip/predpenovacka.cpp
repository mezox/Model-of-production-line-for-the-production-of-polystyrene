#include "predpenovacka.h"

Predpenovacka::Predpenovacka()
{        
}
